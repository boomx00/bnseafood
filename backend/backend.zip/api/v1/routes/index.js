const app = require('express').Router();
const userRoutes = require('./userRoutes')
const tokenRoutes = require('./tokenRoutes')
const contactRoutes = require('./contactRoutes')
//  Routes
app.use('/user', userRoutes);
app.use('/token', tokenRoutes);
app.use('/contact', contactRoutes)
// app.get("/test",(req,res)=>{
//     res.end("hello world")
//   } )
module.exports = app;